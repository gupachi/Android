package com.jw.fb_login_test

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
 private lateinit var auth:FirebaseAuth

  override fun onCreate(saveInstanceState : Bundle?){
 super.onCreate(saveInstanceState)
 setContentView(R.layout.activity_main)

   auth = Firebase.auth

   val btn = findViewById<Button>(R.id.noEmailLoginBtn)
   btn.setOnClickListener{
     auth.signInAnonymously()
      .addOnCompleteListener(this) { task ->
       if(task.isSuccessful) {
        val user = auth.currentUser
       }else{
        Toast.makeText(baseContext, "Authentication failde", Toast.LENGTH_SHORT).show()
       }
      }
   }



 }
}